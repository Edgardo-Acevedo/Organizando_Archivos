
from django.urls import path     
from . import views

urlpatterns = [   
    path('', views.root),
    path('blogs/', views.Index),
    path('blogs/new/', views.new),
    path('blogs/create/', views.create),
    path('blogs/<int:number>/', views.show),
    path('blogs/<int:number>/edit/', views.edit),
    path('blogs/<int:number>/delete/', views.destroy),
]

    # Aplicaciones-route/ esta cosa va después del Aplicaciones-app/
    # localhost:8000/Aplicaciones-app/Aplicaciones-route